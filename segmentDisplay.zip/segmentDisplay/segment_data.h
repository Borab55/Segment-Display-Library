//clear data
bool d[8] = {
     0,
 0,      0,
     0,
 0,     0,
     0,       0
};
//number 0 data
bool d0[8] = {
     1,
 1,      1,
     0,
 1,     1,
     1,       0
};
//number 1 data
bool d1[8] = {
     0,
 0,      1,
     0,
 0,     1,
     0,       0
};
//number 2 data
bool d2[8] = {
     1,
 0,      1,
     1,
 1,     0,
     1,       0
};
//number 3 data
bool d3[8] = {
     1,
 0,      1,
     1,
 0,     1,
     1,       0
};
//number 4 data
bool d4[8] = {
     0,
 1,      1,
     1,
 0,     1,
     0,       0
};
//number 5 data
bool d5[8] = {
     1,
 1,      0,
     1,
 0,     1,
     1,       0
};
//number 6 data
bool d6[8] = {
     1,
 1,      0,
     1,
 1,     1,
     1,       0
};
//number 7 data
bool d7[8] = {
     1,
 0,      1,
     0,
 0,     1,
     0,       0
};
//number 8 data
bool d8[8] = {
     1,
 1,      1,
     1,
 1,     1,
     1,       0
};
//number 9 data
bool d9[8] = {
     1,
 1,      1,
     1,
 0,     1,
     1,       0
};